<?php
$koneksi = mysqli_connect("localhost","root","","proyek");
//var_dump($koneksi);

if(mysqli_connect_error())
{

}
?>